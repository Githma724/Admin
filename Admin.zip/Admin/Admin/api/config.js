// const mongodb = {
//     username: "af_admin",
//     password: "IZdKft3ZafHJEvTn",
// }

const dbconfig = {
    connectionString: `mongodb+srv://gee:gee@cluster0-pexcy.mongodb.net/Test?retryWrites=true&w=majority`,
}

module.exports = { dbconfig }