// business.model.js
const mongoose = require('mongoose');
const Schema = mongoose.Schema;
// Define collection and schema for Business

let Business = new Schema({
    catergory_name: {
        type: String
    },
    catergory_details: {
        type: String
    },
    catergory_number: {
        type: Number
    }
}, {
    collection: 'business'
});
module.exports = mongoose.model('Business', Business);