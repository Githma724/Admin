const mongoose = require('mongoose');
const Schema = mongoose.Schema;


let Manager = new Schema({
      username: { type: String },
      password: { type: String },
      email: { type: String }
}, {
      collection: 'manager'
});




module.exports = mongoose.model('Manager', Manager)
