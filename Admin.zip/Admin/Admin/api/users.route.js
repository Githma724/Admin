const express = require('express');
const usersRoutes = express.Router();


const nodemailer = require('nodemailer');

// Require Business model in our routes module 
let  Manager= require('./users.model');

// Defined store route
usersRoutes.route('/add').post(function (req, res) {
   let manager = new Manager(req.body);
   manager.save()
       .then(manager => {
           res.status(200).json({ 'manager': 'manager in added successfully' });
       })
       .catch(err => {
           res.status(400).send("unable to save to database");
       });

      let email = req.body.email;
      let username =req.body.username;

      const output = `
          <p>You have a successfully become a store manager in our online store.To logged in here are the details </p>
          <h3> Details</p>
          <ul>

            <li>Users name: ${req.body.username}</li>
            <li>Password: ${req.body.password}</li>
            <li>Email: ${req.body.email}</li>  
              
              
          </ul>
      `;
  
      let transporter = nodemailer.createTransport({
          host: "smtp.gmail.com",
          port: 587,
          secure: false, // true for 465, false for other ports
          auth: {
              user: 'githmarpa@gmail.com', // generated ethereal user
              pass: '1234567#@' // generated ethereal password
          }
      });
  
      // send mail with defined transport object
      let info = transporter.sendMail({
          from: '"Admin" <githmarpa@gmail.com>', // sender address
          to: req.body.email, // list of receivers
          subject: "SignUp successfully", // Subject line
          text: "Hello world?", // plain text body
          html: output // html body
      });
  
      console.log("Message sent: %s", info.messageId);
      console.log("Preview URL: %s", nodemailer.getTestMessageUrl(info));
  
});

// Defined get data(index or listing) route 
usersRoutes.route('/').get(function (req, res) {
    Manager.find(function (err, managers) {
      if (err) {
         console.log(err);
      } else {
         res.json(managers);
      }
   });


});


// Defined edit route
usersRoutes.route('/editManager/:id').get(function (req, res) {
    let id = req.params.id;
    Manager.findById(id, function (err, manager) {
        res.json(manager);
    });
});


//  Defined update route
usersRoutes.route('/update/:id').post(function (req, res) {
    Manager.findById(req.params.id, function (err, manager) {
        if (!manager)
            res.status(404).send("data is not found");
        else {
            manager.username = req.body.username;
            manager.password= req.body.password;
            manager.email= req.body.email;

            manager.save().then(manager => {
                res.json('Update complete');
            })
                .catch(err => {
                    res.status(400).send("unable to update the database");
                });
        }
    });
});

// Defined delete | remove | destroy route
usersRoutes.route('/delete/:id').get(function (req, res) {
    Manager.findByIdAndRemove({ _id: req.params.id }, function (err, manager) {
        if (err) res.json(err);
        else res.json('Successfully removed');
    });
});

module.exports = usersRoutes; 