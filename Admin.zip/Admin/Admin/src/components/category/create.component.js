// create.component.js

import React, { Component } from 'react';
import axios from 'axios';

export default class Create extends Component {
    constructor(props) {
        super(props);
        this.onChangeCatergoryName = this.onChangeCatergoryName.bind(this);
        this.onChangeCatergoryDetails= this.onChangeCatergoryDetails.bind(this);
        this.onChangeCatergoryNumber = this.onChangeCatergoryNumber.bind(this);
        this.onSubmit = this.onSubmit.bind(this);

        this.state = {
            catergory_name: '',
            catergory_details: '',
            catergory_number: ''
        }
    }
    onChangeCatergoryName(e) {
        this.setState({
            catergory_name: e.target.value
        });
    }
    onChangeCatergoryDetails(e) {
        this.setState({
            catergory_details: e.target.value
        })
    }
    onChangeCatergoryNumber(e) {
        this.setState({
            catergory_number: e.target.value
        })
    }
    onSubmit(e) {
        e.preventDefault();
        const obj = {
            catergory_name: this.state.catergory_name,
            catergory_details: this.state.catergory_details,
            catergory_number: this.state.catergory_number
        };

        axios.post('http://localhost:5000/business/add', obj)
            .then(res => console.log(res.data));


        this.setState({
            catergory_name: '',
            catergory_details: '',
            catergory_number: ''
        })
    }
    render() {
        return (
            <div style={{ marginTop: 10 }}>
                <h3>Add New Category</h3>
                <form onSubmit={this.onSubmit} method="POST" action="send">
                    <div className="form-group">
                        <label>Category Name:  </label>
                        <input type="text" className="form-control" value={this.state.catergory_name} onChange={this.onChangeCatergoryName} />
                    </div>
                    <div className="form-group">
                        <label>Category details: </label>
                        <input type="text" className="form-control" value={this.state.catergory_details} onChange={this.onChangeCatergoryDetails} />
                    </div>
                    <div className="form-group">
                        <label>Category Number: </label>
                        <input type="text" className="form-control" value={this.state.catergory_number} onChange={this.onChangeCatergoryNumber} />
                    </div>
                    
                    <div className="form-group">
                        <input type="submit" value="Add" className="btn btn-primary" />
                    </div>
                </form>
            </div>
        )
    }
}