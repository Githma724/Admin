// edit.component.js

import React, { Component } from 'react';
import axios from 'axios';

export default class Edit extends Component {
    constructor(props) {
        super(props);
        this.onchangeUserName = this.onchangeUserName.bind(this);
        this.OnchangePassword = this.OnchangePassword.bind(this);
        this.onchangeEmail = this.onchangeEmail.bind(this);
        this.onSubmit = this.onSubmit.bind(this);
        
        this.state = {
            username: '',
            password: '',
            email: '',
            passwordError: '',


        }
    }


    componentDidMount() {
        axios.get('http://localhost:5000/manager/editManager/' + this.props.match.params.id)
            .then(response => {
                this.setState({
                    username: response.data.username,
                    password: response.data.password,
                    email: response.data.email
                });
            }).catch(function (error) {
                console.log(error);
            })
    }

    onchangeUserName(e) {
        this.setState({
            username: e.target.value
        });
    }
    OnchangePassword(e) {
        this.setState({
            password: e.target.value
        })
    }
    onchangeEmail(e) {
        this.setState({
            email: e.target.value
        })
    }
    onSubmit(e) {

        e.preventDefault();

        const obj = {//create an object 
            username: this.state.username,
            password: this.state.password,
            email: this.state.email
        };
        
        axios.post('http://localhost:5000/manager/update/' + this.props.match.params.id, obj)
            .then(res => console.log(res.data)); this.props.history.push('/indexManager');
    }

    render() {
        return (
            <div style={{ marginTop: 10 }}>
                <h3 align="center">Update StockManagers</h3>
                <form onSubmit={this.onSubmit}>
                <div className="form-group">
                        <label>Username</label>
                        <input type="text" className="form-control" placeholder="Username" name="username" value={this.state.username} required onChange={this.onchangeUserName} />
                    </div>
                    <div className="form-group">
                        <label>Password</label>
                        <input type="password" className="form-control" placeholder="Password" name="password" value={this.state.password} required onChange={this.OnchangePassword} />
                    </div>

                    <div className="form-group">
                        <label>Email</label>
                        <input type="email" className="form-control" placeholder="enter email" name="email" value={this.state.email} onChange={this.onchangeEmail} />

                    </div>
                    <div className="form-group">
                        <input type="submit" value="Update Manager details" className="btn btn-primary" />
                    </div>
                </form>
            </div>
        )
    }
}