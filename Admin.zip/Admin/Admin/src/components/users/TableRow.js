// TableRow.js

import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';

class TableRow extends Component {
    constructor(props) {
        super(props);
        this.delete = this.delete.bind(this);
    }


    delete() {
        axios.get('http://localhost:5000/manager/delete/' + this.props.obj._id)
            .then(console.log('Deleted'))
            .catch(err => console.log(err))
    }
    render() {
        return (
            <tr>
                <td>            {this.props.obj.username}</td>
                <td>            {this.props.obj.password}</td>
                <td>            {this.props.obj.email}</td>
                <td><Link to={"/editManager/" + this.props.obj._id} className="btn btn-primary">Edit</Link></td>
                <td><button onClick={this.delete} className="btn btn-danger">Delete</button></td></tr>

        );
    }
}

export default TableRow;