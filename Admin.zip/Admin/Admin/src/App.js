// App.js

import React, { Component } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';
import Create from './components/category/create.component';
import Edit from './components/category/edit.component';
import Index from './components/category/index.component';
import './App.css';

import CreateManager from './components/users/create.component';
import EditManager from './components/users/edit.component';
import IndexManager from './components/users/index.component';


class App extends Component {
  render() {
    return (
      <Router>
        <div className="">
        <div className="container">
          <nav className="navbar navbar-expand-lg navbar-light bg-light">
            <Link to={'/'} className="navbar-brand">Admin page</Link>
            <div className="collapse navbar-collapse" id="navbarSupportedContent">
              <ul className="navbar-nav ">
                <li className="nav-item"><Link to={'/'} className="nav-link">Home</Link></li>
                <li className="nav-item"><Link to={'/create'} className="nav-link">Add Category</Link></li>
                <li className="nav-item"><Link to={'/index'} className="nav-link">View Category</Link></li>

             
                <li className="nav-item1"><Link to={'/createManager'} className="nav-link">Add Manager</Link></li>
                <li className="nav-item2"><Link to={'/indexManager'} className="nav-link">View Manager</Link></li>
                
              </ul>
            </div>
          </nav>
          <br />
          <h2>Online Fashion Store</h2><br />

          <Switch><Route exact path='/create' component={Create} />
            <Route path='/edit/:id' component={Edit} />
            <Route path='/index' component={Index} />

            <Route path='/createManager' component={CreateManager} />
            <Route path='/editManager/:id' component={EditManager} />
            <Route path='/indexManager' component={IndexManager} />
          </Switch>
        </div>
        </div>
      </Router>
    );
  }
}

export default App;